<?php
define('WP_HOME','https://jeromebrownlaw.com/');
define('WP_SITEURL','https://jeromebrownlaw.com/');

#also add
define('FORCE_SSL_ADMIN', true);
if (strpos($_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false)
    $_SERVER['HTTPS']='on';
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'clzej0o2q00039us39aio2z0v');

/** MySQL database username */
define('DB_USER', 'clzej0o2q00029us3bbxhd6kl');

/** MySQL database password */
define('DB_PASSWORD', 'smDd5iAV3rZ7IyqJ5HBjFBy7');

/** MySQL hostname */
define('DB_HOST', 'clzej0o2w0000s39ur3jqu3uq');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '5eca253d06c03960f5573eef5c54e792a64ba9617b135eb1abe7f67c521bbfec');
define('SECURE_AUTH_KEY', 'd39eeb1dc68271089e570ee3d9dc2bf28c734b0a894eeaf837a92e79170631fa');
define('LOGGED_IN_KEY', '470ecffd6c3a94a0dc0cbfc25b555dcbd4782f9987dccdef467480ba8dfb42eb');
define('NONCE_KEY', '4026c4fbcaacf18232c3ff71f1d095a43dfdb0dafbe68c18f35bab7b5f39521d');
define('AUTH_SALT', '0121cc97c8c0dab339a1548bd21465ff7dd9aa880bc103af0d819e48c32a1c61');
define('SECURE_AUTH_SALT', '6bafcd7dbb986252e2247a20d8f5723845fd665afa4e0f9d959ddd50580ab0e4');
define('LOGGED_IN_SALT', '1e04f3f30fd1fa10da380c2963b47008e1ce5869ddfed22183c1e9796ac0cca5');
define('NONCE_SALT', '92ad7d4f473ba287163e2602c3978f64dda57cdcff8d57c6073f36bcd8b6102a');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = '_IZI_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define( 'WP_CRON_LOCK_TIMEOUT', 120   ); 
define( 'AUTOSAVE_INTERVAL',    300   );
define( 'WP_POST_REVISIONS',    5     );
define( 'EMPTY_TRASH_DAYS',     7     );
define( 'WP_AUTO_UPDATE_CORE',  true  );


